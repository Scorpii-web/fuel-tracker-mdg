FUEL TRACKER MDG - Fanamboarana APK amin'ny TELEPHONE IHANY

Tsy mila PC ianao raha mampiasa GitHub Actions (build ao amin'ny cloud).

1. Sokafy ny navigateur amin'ny téléphone ary midira ao amin'ny github.com.
2. Mamoròna compte GitHub raha mbola tsy manana.
3. Mamoròna repository vaovao, ohatra: fuel-tracker-mdg.
4. Ampidiro (upload) ny VOTOATIN'ITY DOSSIER ity ao amin'ilay repository, fa tsy ilay dossier ivelany.
5. Rehefa tafakatra ny fichiers, sokafy ny onglet Actions.
6. Safidio ny workflow "Build Android APK" ary tsindrio "Run workflow" raha tsy mandeha ho azy.
7. Rehefa vita ny build, sokafy ilay exécution farany ary alaivo ny artifact "Fuel-Tracker-MDG-debug-apk".
8. Esory (extract) ilay ZIP nalaina; ao ny app-debug.apk. Tsindrio ilay APK ary avelao ny Android hametraka application avy amin'io source io raha angatahiny.

Fanamarihana:
- Mila Internet rehefa mampakatra source sy misintona APK.
- Tsy mbola manana carte routière offline sy calcul automatique d'itinéraire ity prototype 0.1 ity.
- Ny GPS position ihany no tafiditra; mbola dingana manaraka ny routing sy les cartes Madagascar offline.
- Ny APK debug dia natao hanaovana test, fa tsy release Play Store.
