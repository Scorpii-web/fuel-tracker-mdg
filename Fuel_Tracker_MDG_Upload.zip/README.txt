FUEL TRACKER MDG - Prototype Android

Contenu:
- Interface bilingue Malagasy / Français
- Calcul simple et calcul depuis un trajet saisi manuellement
- Estimation litres et coût en Ariary
- Aller simple / aller-retour
- Choix du véhicule et carburant
- Historique local sur le téléphone
- Récupération de la position GPS du téléphone (autorisation requise)

Limites de cette version 0.1:
- La position GPS ne calcule pas encore automatiquement l'itinéraire.
- La carte complète de Madagascar, le calcul de route et la navigation hors ligne ne sont pas encore intégrés. Il faudra intégrer et tester des données cartographiques/routières téléchargeables pour cela.
- Le résultat carburant est une estimation: relief, état de route, charge, trafic et conduite influencent la consommation réelle.

Pour générer l'APK:
1. Ouvrir le dossier dans Android Studio.
2. Laisser Gradle synchroniser (Android Gradle Plugin 8.7.3).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK de debug: app/build/outputs/apk/debug/app-debug.apk

Compatibilité cible: Android 6.0+ (minSdk 23). Nécessite Android Studio récent / SDK 35 pour compiler.
